<?php

    $g_config['admin_menu'] = array();
?>