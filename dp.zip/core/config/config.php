<?
$g_config['config']['admin_mail'] = 'stuurgurs@yandex.ru';
$g_config['config']['admin_pass'] = 'fMiciar144';
$g_config['config']['admin_name'] = 'stuurgurs';
$g_config['config']['admin_phone1'] = '89787507340';
$g_config['config']['admin_phone2'] = '89787507340';
$g_config['config']['site_adress'] = '';
$g_config['config']['site_name'] = 'New';
$g_config['config']['site_root'] = 'a0091949';

$g_config['config']['db_name'] = 'a0091949_test';
$g_config['config']['db_host'] = 'localhost';
$g_config['config']['db_login'] = 'a0091949_test';
$g_config['config']['db_pass'] = 'cnkfjyt88';
?>