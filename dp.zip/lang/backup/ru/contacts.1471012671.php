<?php

$g_lang['head_no_tags'] = 'Контакты';
$g_lang['text']    = 'Страница наполняется';
?>