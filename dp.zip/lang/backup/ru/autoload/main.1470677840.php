<?php

    $g_lang["m_titlePostfix"] = "Новый сайт";

    $g_lang["m_title"] = "Новый сайт";
    $g_lang["m_keyWords"] = "Новый сайт";
    $g_lang["m_description"] = "Новый сайт";
    $g_lang["phone"] = "(044) 390-45-87";
    $g_lang["phone2"] = "(044) 499-59-86";
?>