<?php

    $g_lang["head_no_tags"] = "Контакты";
    $g_lang["text"] = "<div class=\"uk-panel-title\" style=\"font-family: 'Exo 2', sans-serif; margin-top: 0px; margin-bottom: 15px; font-size: 18px; line-height: 24px; color: rgb(68, 68, 68);\">  <div class=\"uk-panel-title\" style=\"margin-top: 0px; margin-bottom: 15px; line-height: 24px;\">  <div class=\"uk-panel-title\" style=\"font-family: 'Exo 2', sans-serif; margin-top: 0px; margin-bottom: 15px; font-size: 18px; line-height: 24px; color: rgb(68, 68, 68);\">Офис в Ялте</div>    <p>ул. Строителей, 6А, лит.&quot;В&quot;, 2 этаж<br />  8 (800) 500 43 07<br />  7 (978) 917 91 11 (WIN)<br />  7 (978) 011 99 22 (MTC)</p>  Офис в Москве</div>    <p>ул.Амурская дом 3,стр 13<br />  Почтовый индекс: 107553<br />  +7 495 235 60 20</p>  </div>  ";

?>