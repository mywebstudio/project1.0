<?php

    $g_lang['welcome'] = 'Добро пожаловать в Micron!';
    $g_lang['message'] = 'Дорогой пользователь, добро пожаловать в микрон - самый простой пхп фреймворк.';
    $g_lang['build']   = 'Build %s';
    $g_lang['text']   = '';
?>
