<?php

    $g_lang['menu'] = 'Меню';
?>
