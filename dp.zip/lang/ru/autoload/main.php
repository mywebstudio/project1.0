<?php

    $g_lang["m_titlePostfix"] = "Кухни АТЛАС-ЛЮКС Севастополь ";
    $g_lang["phone"] = "";
    $g_lang["phone2"] = "";

    $g_lang["m_title"] = "";
    $g_lang["m_keyWords"] = "";
    $g_lang["m_description"] = "";
?>